﻿namespace ZaverecnyProjektIT4_2023
{
    partial class EditUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonCancel = new Button();
            buttonEditUser = new Button();
            label4 = new Label();
            comboBoxRole = new ComboBox();
            textBoxUsername = new TextBox();
            label2 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // buttonCancel
            // 
            buttonCancel.Location = new Point(13, 148);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(75, 23);
            buttonCancel.TabIndex = 17;
            buttonCancel.Text = "Zrušit";
            buttonCancel.UseVisualStyleBackColor = true;
            // 
            // buttonEditUser
            // 
            buttonEditUser.Location = new Point(94, 148);
            buttonEditUser.Name = "buttonEditUser";
            buttonEditUser.Size = new Size(75, 23);
            buttonEditUser.TabIndex = 16;
            buttonEditUser.Text = "Upravit";
            buttonEditUser.UseVisualStyleBackColor = true;
            buttonEditUser.Click += buttonEditUser_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(69, 84);
            label4.Name = "label4";
            label4.Size = new Size(33, 15);
            label4.TabIndex = 15;
            label4.Text = "Role:";
            // 
            // comboBoxRole
            // 
            comboBoxRole.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxRole.FormattingEnabled = true;
            comboBoxRole.Items.AddRange(new object[] { "admin", "user" });
            comboBoxRole.Location = new Point(37, 102);
            comboBoxRole.Name = "comboBoxRole";
            comboBoxRole.Size = new Size(100, 23);
            comboBoxRole.TabIndex = 14;
            // 
            // textBoxUsername
            // 
            textBoxUsername.Location = new Point(37, 58);
            textBoxUsername.Name = "textBoxUsername";
            textBoxUsername.Size = new Size(100, 23);
            textBoxUsername.TabIndex = 11;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(37, 40);
            label2.Name = "label2";
            label2.Size = new Size(102, 15);
            label2.TabIndex = 10;
            label2.Text = "Uživatelské jméno";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(157, 21);
            label1.TabIndex = 9;
            label1.Text = "Editování uživatele";
            // 
            // EditUser
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(182, 195);
            Controls.Add(buttonCancel);
            Controls.Add(buttonEditUser);
            Controls.Add(label4);
            Controls.Add(comboBoxRole);
            Controls.Add(textBoxUsername);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "EditUser";
            Text = "EditUser";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonCancel;
        private Button buttonEditUser;
        private Label label4;
        private ComboBox comboBoxRole;
        private TextBox textBoxUsername;
        private Label label2;
        private Label label1;
    }
}