﻿namespace ZaverecnyProjektIT4_2023
{
    partial class AddEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonCancel = new Button();
            buttonAddWork = new Button();
            textBoxLastName = new TextBox();
            label3 = new Label();
            textBoxFirstName = new TextBox();
            label2 = new Label();
            label1 = new Label();
            textBoxJob = new TextBox();
            label4 = new Label();
            label5 = new Label();
            dateTimePicker = new DateTimePicker();
            textBoxEmail = new TextBox();
            label6 = new Label();
            textBoxPhone = new TextBox();
            label7 = new Label();
            SuspendLayout();
            // 
            // buttonCancel
            // 
            buttonCancel.Location = new Point(56, 240);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(75, 23);
            buttonCancel.TabIndex = 24;
            buttonCancel.Text = "Zrušit";
            buttonCancel.UseVisualStyleBackColor = true;
            buttonCancel.Click += buttonCancel_Click;
            // 
            // buttonAddWork
            // 
            buttonAddWork.Location = new Point(137, 240);
            buttonAddWork.Name = "buttonAddWork";
            buttonAddWork.Size = new Size(75, 23);
            buttonAddWork.TabIndex = 23;
            buttonAddWork.Text = "Přidat";
            buttonAddWork.UseVisualStyleBackColor = true;
            buttonAddWork.Click += buttonAddEmployee_Click;
            // 
            // textBoxLastName
            // 
            textBoxLastName.Location = new Point(137, 115);
            textBoxLastName.Name = "textBoxLastName";
            textBoxLastName.Size = new Size(148, 23);
            textBoxLastName.TabIndex = 22;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(137, 97);
            label3.Name = "label3";
            label3.Size = new Size(54, 15);
            label3.TabIndex = 21;
            label3.Text = "Příjmení:";
            // 
            // textBoxFirstName
            // 
            textBoxFirstName.Location = new Point(4, 115);
            textBoxFirstName.Name = "textBoxFirstName";
            textBoxFirstName.Size = new Size(127, 23);
            textBoxFirstName.TabIndex = 20;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(4, 97);
            label2.Name = "label2";
            label2.Size = new Size(83, 15);
            label2.TabIndex = 19;
            label2.Text = "Křestní jméno:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(187, 21);
            label1.TabIndex = 18;
            label1.Text = "Přidávání zaměstnance";
            // 
            // textBoxJob
            // 
            textBoxJob.Location = new Point(4, 67);
            textBoxJob.Name = "textBoxJob";
            textBoxJob.Size = new Size(100, 23);
            textBoxJob.TabIndex = 26;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 49);
            label4.Name = "label4";
            label4.Size = new Size(28, 15);
            label4.TabIndex = 25;
            label4.Text = "Job:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 149);
            label5.Name = "label5";
            label5.Size = new Size(81, 15);
            label5.TabIndex = 27;
            label5.Text = "Datum naroz.:";
            // 
            // dateTimePicker
            // 
            dateTimePicker.Location = new Point(4, 167);
            dateTimePicker.Name = "dateTimePicker";
            dateTimePicker.Size = new Size(281, 23);
            dateTimePicker.TabIndex = 28;
            // 
            // textBoxEmail
            // 
            textBoxEmail.Location = new Point(4, 210);
            textBoxEmail.Name = "textBoxEmail";
            textBoxEmail.Size = new Size(100, 23);
            textBoxEmail.TabIndex = 30;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(6, 193);
            label6.Name = "label6";
            label6.Size = new Size(39, 15);
            label6.TabIndex = 29;
            label6.Text = "Email:";
            // 
            // textBoxPhone
            // 
            textBoxPhone.Location = new Point(110, 210);
            textBoxPhone.Name = "textBoxPhone";
            textBoxPhone.Size = new Size(175, 23);
            textBoxPhone.TabIndex = 32;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(112, 193);
            label7.Name = "label7";
            label7.Size = new Size(27, 15);
            label7.TabIndex = 31;
            label7.Text = "Tel.:";
            // 
            // AddEmployee
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(290, 268);
            Controls.Add(textBoxPhone);
            Controls.Add(label7);
            Controls.Add(textBoxEmail);
            Controls.Add(label6);
            Controls.Add(dateTimePicker);
            Controls.Add(label5);
            Controls.Add(textBoxJob);
            Controls.Add(label4);
            Controls.Add(buttonCancel);
            Controls.Add(buttonAddWork);
            Controls.Add(textBoxLastName);
            Controls.Add(label3);
            Controls.Add(textBoxFirstName);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "AddEmployee";
            Text = "AddEmployee";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonCancel;
        private Button buttonAddWork;
        private TextBox textBoxLastName;
        private Label label3;
        private TextBox textBoxFirstName;
        private Label label2;
        private Label label1;
        private TextBox textBoxJob;
        private Label label4;
        private Label label5;
        private DateTimePicker dateTimePicker;
        private TextBox textBoxEmail;
        private Label label6;
        private TextBox textBoxPhone;
        private Label label7;
    }
}