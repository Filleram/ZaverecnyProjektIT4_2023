﻿namespace ZaverecnyProjektIT4_2023
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            buttonAddUser = new Button();
            buttonEditUser = new Button();
            buttonDeleteUser = new Button();
            label2 = new Label();
            textBoxSearchUser = new TextBox();
            listViewUsers = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            label1 = new Label();
            panel2 = new Panel();
            buttonAddEmployee = new Button();
            buttonEditEmployee = new Button();
            buttonDeleteEmployee = new Button();
            label3 = new Label();
            textBoxSearchEmployee = new TextBox();
            listViewEmployees = new ListView();
            columnHeader4 = new ColumnHeader();
            columnHeader7 = new ColumnHeader();
            columnHeader5 = new ColumnHeader();
            columnHeader6 = new ColumnHeader();
            columnHeader8 = new ColumnHeader();
            columnHeader9 = new ColumnHeader();
            columnHeader10 = new ColumnHeader();
            label4 = new Label();
            panel3 = new Panel();
            buttonAddWork = new Button();
            buttonEditWork = new Button();
            buttonDeleteWork = new Button();
            label5 = new Label();
            textBoxSearchWorks = new TextBox();
            listViewWorks = new ListView();
            columnHeader11 = new ColumnHeader();
            columnHeader12 = new ColumnHeader();
            columnHeader13 = new ColumnHeader();
            label6 = new Label();
            panel4 = new Panel();
            label11 = new Label();
            buttonAddContract = new Button();
            buttonDeleteContract = new Button();
            label7 = new Label();
            textBoxSearchContacts = new TextBox();
            listViewContracts = new ListView();
            columnHeader14 = new ColumnHeader();
            columnHeader15 = new ColumnHeader();
            columnHeader16 = new ColumnHeader();
            columnHeader17 = new ColumnHeader();
            columnHeader18 = new ColumnHeader();
            columnHeader19 = new ColumnHeader();
            label8 = new Label();
            panel5 = new Panel();
            button10 = new Button();
            label10 = new Label();
            label9 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.Control;
            panel1.Controls.Add(buttonAddUser);
            panel1.Controls.Add(buttonEditUser);
            panel1.Controls.Add(buttonDeleteUser);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(textBoxSearchUser);
            panel1.Controls.Add(listViewUsers);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(304, 426);
            panel1.TabIndex = 0;
            // 
            // buttonAddUser
            // 
            buttonAddUser.Location = new Point(187, 342);
            buttonAddUser.Name = "buttonAddUser";
            buttonAddUser.Size = new Size(75, 23);
            buttonAddUser.TabIndex = 7;
            buttonAddUser.Text = "Přidat";
            buttonAddUser.UseVisualStyleBackColor = true;
            buttonAddUser.Click += buttonAddUser_Click;
            // 
            // buttonEditUser
            // 
            buttonEditUser.Location = new Point(188, 371);
            buttonEditUser.Name = "buttonEditUser";
            buttonEditUser.Size = new Size(75, 23);
            buttonEditUser.TabIndex = 6;
            buttonEditUser.Text = "Upravit";
            buttonEditUser.UseVisualStyleBackColor = true;
            buttonEditUser.Click += buttonEditUser_Click;
            // 
            // buttonDeleteUser
            // 
            buttonDeleteUser.Location = new Point(188, 400);
            buttonDeleteUser.Name = "buttonDeleteUser";
            buttonDeleteUser.Size = new Size(75, 23);
            buttonDeleteUser.TabIndex = 5;
            buttonDeleteUser.Text = "Smazat";
            buttonDeleteUser.UseVisualStyleBackColor = true;
            buttonDeleteUser.Click += buttonDeleteUser_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(188, 25);
            label2.Name = "label2";
            label2.Size = new Size(74, 15);
            label2.TabIndex = 4;
            label2.Text = "Vyhledávání:";
            // 
            // textBoxSearchUser
            // 
            textBoxSearchUser.Location = new Point(188, 43);
            textBoxSearchUser.Name = "textBoxSearchUser";
            textBoxSearchUser.Size = new Size(105, 23);
            textBoxSearchUser.TabIndex = 3;
            textBoxSearchUser.TextChanged += textBoxSearchUser_TextChanged;
            // 
            // listViewUsers
            // 
            listViewUsers.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3 });
            listViewUsers.FullRowSelect = true;
            listViewUsers.GridLines = true;
            listViewUsers.Location = new Point(0, 24);
            listViewUsers.Name = "listViewUsers";
            listViewUsers.Size = new Size(182, 402);
            listViewUsers.TabIndex = 2;
            listViewUsers.UseCompatibleStateImageBehavior = false;
            listViewUsers.View = View.Details;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "Id";
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Username";
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "Role";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(3, 0);
            label1.Name = "label1";
            label1.Size = new Size(82, 21);
            label1.TabIndex = 1;
            label1.Text = "Uživatelé";
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.Control;
            panel2.Controls.Add(buttonAddEmployee);
            panel2.Controls.Add(buttonEditEmployee);
            panel2.Controls.Add(buttonDeleteEmployee);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(textBoxSearchEmployee);
            panel2.Controls.Add(listViewEmployees);
            panel2.Controls.Add(label4);
            panel2.Location = new Point(322, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(631, 426);
            panel2.TabIndex = 8;
            // 
            // buttonAddEmployee
            // 
            buttonAddEmployee.Location = new Point(510, 342);
            buttonAddEmployee.Name = "buttonAddEmployee";
            buttonAddEmployee.Size = new Size(75, 23);
            buttonAddEmployee.TabIndex = 7;
            buttonAddEmployee.Text = "Přidat";
            buttonAddEmployee.UseVisualStyleBackColor = true;
            buttonAddEmployee.Click += buttonAddEmployee_Click_1;
            // 
            // buttonEditEmployee
            // 
            buttonEditEmployee.Location = new Point(511, 371);
            buttonEditEmployee.Name = "buttonEditEmployee";
            buttonEditEmployee.Size = new Size(75, 23);
            buttonEditEmployee.TabIndex = 6;
            buttonEditEmployee.Text = "Upravit";
            buttonEditEmployee.UseVisualStyleBackColor = true;
            buttonEditEmployee.Click += buttonEditEmployee_Click;
            // 
            // buttonDeleteEmployee
            // 
            buttonDeleteEmployee.Location = new Point(511, 400);
            buttonDeleteEmployee.Name = "buttonDeleteEmployee";
            buttonDeleteEmployee.Size = new Size(75, 23);
            buttonDeleteEmployee.TabIndex = 5;
            buttonDeleteEmployee.Text = "Smazat";
            buttonDeleteEmployee.UseVisualStyleBackColor = true;
            buttonDeleteEmployee.Click += buttonDeleteEmployee_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(511, 25);
            label3.Name = "label3";
            label3.Size = new Size(74, 15);
            label3.TabIndex = 4;
            label3.Text = "Vyhledávání:";
            // 
            // textBoxSearchEmployee
            // 
            textBoxSearchEmployee.Location = new Point(511, 43);
            textBoxSearchEmployee.Name = "textBoxSearchEmployee";
            textBoxSearchEmployee.Size = new Size(105, 23);
            textBoxSearchEmployee.TabIndex = 3;
            textBoxSearchEmployee.TextChanged += textBoxSearchEmployee_TextChanged;
            // 
            // listViewEmployees
            // 
            listViewEmployees.Columns.AddRange(new ColumnHeader[] { columnHeader4, columnHeader7, columnHeader5, columnHeader6, columnHeader8, columnHeader9, columnHeader10 });
            listViewEmployees.FullRowSelect = true;
            listViewEmployees.GridLines = true;
            listViewEmployees.Location = new Point(0, 24);
            listViewEmployees.Name = "listViewEmployees";
            listViewEmployees.Size = new Size(505, 402);
            listViewEmployees.TabIndex = 2;
            listViewEmployees.UseCompatibleStateImageBehavior = false;
            listViewEmployees.View = View.Details;
            // 
            // columnHeader4
            // 
            columnHeader4.Text = "EmployeeId";
            // 
            // columnHeader7
            // 
            columnHeader7.DisplayIndex = 3;
            columnHeader7.Text = "Job";
            // 
            // columnHeader5
            // 
            columnHeader5.DisplayIndex = 1;
            columnHeader5.Text = "Firstname";
            // 
            // columnHeader6
            // 
            columnHeader6.DisplayIndex = 2;
            columnHeader6.Text = "Lastname";
            // 
            // columnHeader8
            // 
            columnHeader8.Text = "Birthdate";
            // 
            // columnHeader9
            // 
            columnHeader9.Text = "Email";
            // 
            // columnHeader10
            // 
            columnHeader10.Text = "Phone";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(3, 0);
            label4.Name = "label4";
            label4.Size = new Size(108, 21);
            label4.TabIndex = 1;
            label4.Text = "Zaměstnanci";
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.Control;
            panel3.Controls.Add(buttonAddWork);
            panel3.Controls.Add(buttonEditWork);
            panel3.Controls.Add(buttonDeleteWork);
            panel3.Controls.Add(label5);
            panel3.Controls.Add(textBoxSearchWorks);
            panel3.Controls.Add(listViewWorks);
            panel3.Controls.Add(label6);
            panel3.Location = new Point(12, 444);
            panel3.Name = "panel3";
            panel3.Size = new Size(304, 297);
            panel3.TabIndex = 8;
            // 
            // buttonAddWork
            // 
            buttonAddWork.Location = new Point(187, 213);
            buttonAddWork.Name = "buttonAddWork";
            buttonAddWork.Size = new Size(75, 23);
            buttonAddWork.TabIndex = 7;
            buttonAddWork.Text = "Přidat";
            buttonAddWork.UseVisualStyleBackColor = true;
            buttonAddWork.Click += buttonAddWork_Click;
            // 
            // buttonEditWork
            // 
            buttonEditWork.Location = new Point(188, 242);
            buttonEditWork.Name = "buttonEditWork";
            buttonEditWork.Size = new Size(75, 23);
            buttonEditWork.TabIndex = 6;
            buttonEditWork.Text = "Upravit";
            buttonEditWork.UseVisualStyleBackColor = true;
            buttonEditWork.Click += buttonEditWork_Click;
            // 
            // buttonDeleteWork
            // 
            buttonDeleteWork.Location = new Point(188, 271);
            buttonDeleteWork.Name = "buttonDeleteWork";
            buttonDeleteWork.Size = new Size(75, 23);
            buttonDeleteWork.TabIndex = 5;
            buttonDeleteWork.Text = "Smazat";
            buttonDeleteWork.UseVisualStyleBackColor = true;
            buttonDeleteWork.Click += buttonDeleteWork_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(188, 25);
            label5.Name = "label5";
            label5.Size = new Size(74, 15);
            label5.TabIndex = 4;
            label5.Text = "Vyhledávání:";
            // 
            // textBoxSearchWorks
            // 
            textBoxSearchWorks.Location = new Point(188, 43);
            textBoxSearchWorks.Name = "textBoxSearchWorks";
            textBoxSearchWorks.Size = new Size(105, 23);
            textBoxSearchWorks.TabIndex = 3;
            textBoxSearchWorks.TextChanged += textBoxSearchWorks_TextChanged;
            // 
            // listViewWorks
            // 
            listViewWorks.Columns.AddRange(new ColumnHeader[] { columnHeader11, columnHeader12, columnHeader13 });
            listViewWorks.FullRowSelect = true;
            listViewWorks.GridLines = true;
            listViewWorks.Location = new Point(0, 24);
            listViewWorks.Name = "listViewWorks";
            listViewWorks.Size = new Size(182, 273);
            listViewWorks.TabIndex = 2;
            listViewWorks.UseCompatibleStateImageBehavior = false;
            listViewWorks.View = View.Details;
            // 
            // columnHeader11
            // 
            columnHeader11.Text = "WorkId";
            // 
            // columnHeader12
            // 
            columnHeader12.Text = "Name";
            // 
            // columnHeader13
            // 
            columnHeader13.Text = "Description";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(3, 0);
            label6.Name = "label6";
            label6.Size = new Size(52, 21);
            label6.TabIndex = 1;
            label6.Text = "Práce";
            // 
            // panel4
            // 
            panel4.BackColor = SystemColors.Control;
            panel4.Controls.Add(label11);
            panel4.Controls.Add(buttonAddContract);
            panel4.Controls.Add(buttonDeleteContract);
            panel4.Controls.Add(label7);
            panel4.Controls.Add(textBoxSearchContacts);
            panel4.Controls.Add(listViewContracts);
            panel4.Controls.Add(label8);
            panel4.Location = new Point(322, 444);
            panel4.Name = "panel4";
            panel4.Size = new Size(505, 297);
            panel4.TabIndex = 9;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(394, 69);
            label11.Name = "label11";
            label11.Size = new Size(100, 15);
            label11.TabIndex = 8;
            label11.Text = "(podle Customer)";
            // 
            // buttonAddContract
            // 
            buttonAddContract.Location = new Point(394, 242);
            buttonAddContract.Name = "buttonAddContract";
            buttonAddContract.Size = new Size(75, 23);
            buttonAddContract.TabIndex = 7;
            buttonAddContract.Text = "Přidat";
            buttonAddContract.UseVisualStyleBackColor = true;
            buttonAddContract.Click += buttonAddContract_Click;
            // 
            // buttonDeleteContract
            // 
            buttonDeleteContract.Location = new Point(394, 271);
            buttonDeleteContract.Name = "buttonDeleteContract";
            buttonDeleteContract.Size = new Size(75, 23);
            buttonDeleteContract.TabIndex = 5;
            buttonDeleteContract.Text = "Smazat";
            buttonDeleteContract.UseVisualStyleBackColor = true;
            buttonDeleteContract.Click += buttonDeleteContract_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(394, 25);
            label7.Name = "label7";
            label7.Size = new Size(74, 15);
            label7.TabIndex = 4;
            label7.Text = "Vyhledávání:";
            // 
            // textBoxSearchContacts
            // 
            textBoxSearchContacts.Location = new Point(394, 43);
            textBoxSearchContacts.Name = "textBoxSearchContacts";
            textBoxSearchContacts.Size = new Size(105, 23);
            textBoxSearchContacts.TabIndex = 3;
            textBoxSearchContacts.TextChanged += textBoxSearchContacts_TextChanged;
            // 
            // listViewContracts
            // 
            listViewContracts.Columns.AddRange(new ColumnHeader[] { columnHeader14, columnHeader15, columnHeader16, columnHeader17, columnHeader18, columnHeader19 });
            listViewContracts.FullRowSelect = true;
            listViewContracts.GridLines = true;
            listViewContracts.Location = new Point(0, 27);
            listViewContracts.Name = "listViewContracts";
            listViewContracts.Size = new Size(388, 270);
            listViewContracts.TabIndex = 2;
            listViewContracts.UseCompatibleStateImageBehavior = false;
            listViewContracts.View = View.Details;
            // 
            // columnHeader14
            // 
            columnHeader14.Text = "ContractId";
            // 
            // columnHeader15
            // 
            columnHeader15.Text = "Work";
            // 
            // columnHeader16
            // 
            columnHeader16.Text = "Employee";
            // 
            // columnHeader17
            // 
            columnHeader17.Text = "CustomerName";
            // 
            // columnHeader18
            // 
            columnHeader18.Text = "Date";
            // 
            // columnHeader19
            // 
            columnHeader19.Text = "Hours";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(3, 0);
            label8.Name = "label8";
            label8.Size = new Size(73, 21);
            label8.TabIndex = 1;
            label8.Text = "Zakázky";
            // 
            // panel5
            // 
            panel5.BackColor = SystemColors.Control;
            panel5.Controls.Add(button10);
            panel5.Controls.Add(label10);
            panel5.Controls.Add(label9);
            panel5.Location = new Point(832, 444);
            panel5.Name = "panel5";
            panel5.Size = new Size(121, 297);
            panel5.TabIndex = 10;
            // 
            // button10
            // 
            button10.Location = new Point(43, 271);
            button10.Name = "button10";
            button10.Size = new Size(75, 23);
            button10.TabIndex = 8;
            button10.Text = "Odhlásit se";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(3, 25);
            label10.Name = "label10";
            label10.Size = new Size(44, 15);
            label10.TabIndex = 3;
            label10.Text = "label10";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label9.Location = new Point(0, 3);
            label9.Name = "label9";
            label9.Size = new Size(63, 19);
            label9.TabIndex = 2;
            label9.Text = "Uživatel";
            // 
            // AdminForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(965, 753);
            Controls.Add(panel5);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "AdminForm";
            Text = "AdminForm";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button buttonAddUser;
        private Button buttonEditUser;
        private Button buttonDeleteUser;
        private Label label2;
        private TextBox textBoxSearchUser;
        private ListView listViewUsers;
        private Label label1;
        private Panel panel2;
        private Button buttonAddEmployee;
        private Button buttonEditEmployee;
        private Button buttonDeleteEmployee;
        private Label label3;
        private TextBox textBoxSearchEmployee;
        private ListView listViewEmployees;
        private Label label4;
        private Panel panel3;
        private Button buttonAddWork;
        private Button buttonEditWork;
        private Button buttonDeleteWork;
        private Label label5;
        private TextBox textBoxSearchWorks;
        private ListView listViewWorks;
        private Label label6;
        private Panel panel4;
        private Button buttonAddContract;
        private Button buttonDeleteContract;
        private Label label7;
        private TextBox textBoxSearchContacts;
        private ListView listViewContracts;
        private Label label8;
        private Panel panel5;
        private Button button10;
        private Label label10;
        private Label label9;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private ColumnHeader columnHeader7;
        private ColumnHeader columnHeader5;
        private ColumnHeader columnHeader6;
        private ColumnHeader columnHeader8;
        private ColumnHeader columnHeader9;
        private ColumnHeader columnHeader10;
        private ColumnHeader columnHeader11;
        private ColumnHeader columnHeader12;
        private ColumnHeader columnHeader13;
        private ColumnHeader columnHeader14;
        private ColumnHeader columnHeader15;
        private ColumnHeader columnHeader16;
        private ColumnHeader columnHeader17;
        private ColumnHeader columnHeader18;
        private ColumnHeader columnHeader19;
        private Label label11;
    }
}