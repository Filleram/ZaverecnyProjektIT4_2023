﻿namespace ZaverecnyProjektIT4_2023
{
    partial class AddWork
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonCancel = new Button();
            buttonAddWork = new Button();
            textBoxDescription = new TextBox();
            label3 = new Label();
            textBoxName = new TextBox();
            label2 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // buttonCancel
            // 
            buttonCancel.Location = new Point(30, 540);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(75, 23);
            buttonCancel.TabIndex = 17;
            buttonCancel.Text = "Zrušit";
            buttonCancel.UseVisualStyleBackColor = true;
            buttonCancel.Click += buttonCancel_Click;
            // 
            // buttonAddWork
            // 
            buttonAddWork.Location = new Point(146, 540);
            buttonAddWork.Name = "buttonAddWork";
            buttonAddWork.Size = new Size(75, 23);
            buttonAddWork.TabIndex = 16;
            buttonAddWork.Text = "Přidat";
            buttonAddWork.UseVisualStyleBackColor = true;
            buttonAddWork.Click += buttonAddWork_Click;
            // 
            // textBoxDescription
            // 
            textBoxDescription.Location = new Point(12, 99);
            textBoxDescription.Multiline = true;
            textBoxDescription.Name = "textBoxDescription";
            textBoxDescription.Size = new Size(245, 435);
            textBoxDescription.TabIndex = 13;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 81);
            label3.Name = "label3";
            label3.Size = new Size(39, 15);
            label3.TabIndex = 12;
            label3.Text = "Popis:";
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(57, 48);
            textBoxName.Multiline = true;
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(200, 23);
            textBoxName.TabIndex = 11;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(9, 51);
            label2.Name = "label2";
            label2.Size = new Size(42, 15);
            label2.TabIndex = 10;
            label2.Text = "Název:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(9, 12);
            label1.Name = "label1";
            label1.Size = new Size(122, 21);
            label1.TabIndex = 9;
            label1.Text = "Přidávání jobu";
            // 
            // AddWork
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(269, 575);
            Controls.Add(buttonCancel);
            Controls.Add(buttonAddWork);
            Controls.Add(textBoxDescription);
            Controls.Add(label3);
            Controls.Add(textBoxName);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "AddWork";
            Text = "AddWork";
            Load += AddWork_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonCancel;
        private Button buttonAddWork;
        private TextBox textBoxDescription;
        private Label label3;
        private TextBox textBoxName;
        private Label label2;
        private Label label1;
    }
}