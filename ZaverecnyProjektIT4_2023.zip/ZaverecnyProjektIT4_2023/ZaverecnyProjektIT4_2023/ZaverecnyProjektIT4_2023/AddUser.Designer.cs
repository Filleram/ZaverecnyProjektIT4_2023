﻿namespace ZaverecnyProjektIT4_2023
{
    partial class AddUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            textBoxUsername = new TextBox();
            textBoPassword = new TextBox();
            label3 = new Label();
            comboBoxRole = new ComboBox();
            label4 = new Label();
            buttonAddUser = new Button();
            buttonCancel = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(157, 21);
            label1.TabIndex = 0;
            label1.Text = "Přidávání uživatele";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 48);
            label2.Name = "label2";
            label2.Size = new Size(102, 15);
            label2.TabIndex = 1;
            label2.Text = "Uživatelské jméno";
            // 
            // textBoxUsername
            // 
            textBoxUsername.Location = new Point(14, 66);
            textBoxUsername.Name = "textBoxUsername";
            textBoxUsername.Size = new Size(155, 23);
            textBoxUsername.TabIndex = 2;
            // 
            // textBoPassword
            // 
            textBoPassword.Location = new Point(14, 110);
            textBoPassword.Name = "textBoPassword";
            textBoPassword.Size = new Size(155, 23);
            textBoPassword.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 92);
            label3.Name = "label3";
            label3.Size = new Size(40, 15);
            label3.TabIndex = 3;
            label3.Text = "Heslo:";
            // 
            // comboBoxRole
            // 
            comboBoxRole.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxRole.FormattingEnabled = true;
            comboBoxRole.Items.AddRange(new object[] { "admin", "user" });
            comboBoxRole.Location = new Point(14, 154);
            comboBoxRole.Name = "comboBoxRole";
            comboBoxRole.Size = new Size(156, 23);
            comboBoxRole.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(14, 136);
            label4.Name = "label4";
            label4.Size = new Size(33, 15);
            label4.TabIndex = 6;
            label4.Text = "Role:";
            // 
            // buttonAddUser
            // 
            buttonAddUser.Location = new Point(94, 193);
            buttonAddUser.Name = "buttonAddUser";
            buttonAddUser.Size = new Size(75, 23);
            buttonAddUser.TabIndex = 7;
            buttonAddUser.Text = "Přidat";
            buttonAddUser.UseVisualStyleBackColor = true;
            buttonAddUser.Click += buttonAddUser_Click;
            // 
            // buttonCancel
            // 
            buttonCancel.Location = new Point(13, 193);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(75, 23);
            buttonCancel.TabIndex = 8;
            buttonCancel.Text = "Zrušit";
            buttonCancel.UseVisualStyleBackColor = true;
            buttonCancel.Click += buttonCancel_Click;
            // 
            // AddUser
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(182, 229);
            Controls.Add(buttonCancel);
            Controls.Add(buttonAddUser);
            Controls.Add(label4);
            Controls.Add(comboBoxRole);
            Controls.Add(textBoPassword);
            Controls.Add(label3);
            Controls.Add(textBoxUsername);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "AddUser";
            Text = "AddUser";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox textBoxUsername;
        private TextBox textBoPassword;
        private Label label3;
        private ComboBox comboBoxRole;
        private Label label4;
        private Button buttonAddUser;
        private Button buttonCancel;
    }
}