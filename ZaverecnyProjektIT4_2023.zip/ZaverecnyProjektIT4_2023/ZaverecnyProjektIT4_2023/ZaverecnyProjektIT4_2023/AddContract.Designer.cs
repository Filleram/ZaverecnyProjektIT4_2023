﻿namespace ZaverecnyProjektIT4_2023
{
    partial class AddContract
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxCustomerName = new TextBox();
            label6 = new Label();
            dateTimePicker = new DateTimePicker();
            label5 = new Label();
            textBoxWorkId = new TextBox();
            label4 = new Label();
            buttonCancel = new Button();
            buttonAddContract = new Button();
            textBoxEmplyoeeId = new TextBox();
            label2 = new Label();
            label1 = new Label();
            label3 = new Label();
            textBoxHours = new TextBox();
            SuspendLayout();
            // 
            // textBoxCustomerName
            // 
            textBoxCustomerName.Location = new Point(12, 145);
            textBoxCustomerName.Name = "textBoxCustomerName";
            textBoxCustomerName.Size = new Size(174, 23);
            textBoxCustomerName.TabIndex = 45;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(12, 127);
            label6.Name = "label6";
            label6.Size = new Size(98, 15);
            label6.TabIndex = 44;
            label6.Text = "Jméno zákazníka:";
            // 
            // dateTimePicker
            // 
            dateTimePicker.Location = new Point(12, 189);
            dateTimePicker.Name = "dateTimePicker";
            dateTimePicker.Size = new Size(174, 23);
            dateTimePicker.TabIndex = 43;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 171);
            label5.Name = "label5";
            label5.Size = new Size(46, 15);
            label5.TabIndex = 42;
            label5.Text = "Datum:";
            // 
            // textBoxWorkId
            // 
            textBoxWorkId.Location = new Point(12, 57);
            textBoxWorkId.Name = "textBoxWorkId";
            textBoxWorkId.Size = new Size(174, 23);
            textBoxWorkId.TabIndex = 41;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 39);
            label4.Name = "label4";
            label4.Size = new Size(47, 15);
            label4.TabIndex = 40;
            label4.Text = "ID work";
            // 
            // buttonCancel
            // 
            buttonCancel.Location = new Point(18, 262);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(75, 23);
            buttonCancel.TabIndex = 39;
            buttonCancel.Text = "Zrušit";
            buttonCancel.UseVisualStyleBackColor = true;
            buttonCancel.Click += buttonCancel_Click;
            // 
            // buttonAddContract
            // 
            buttonAddContract.Location = new Point(99, 262);
            buttonAddContract.Name = "buttonAddContract";
            buttonAddContract.Size = new Size(75, 23);
            buttonAddContract.TabIndex = 38;
            buttonAddContract.Text = "Přidat";
            buttonAddContract.UseVisualStyleBackColor = true;
            buttonAddContract.Click += buttonAddContract_Click;
            // 
            // textBoxEmplyoeeId
            // 
            textBoxEmplyoeeId.Location = new Point(12, 101);
            textBoxEmplyoeeId.Name = "textBoxEmplyoeeId";
            textBoxEmplyoeeId.Size = new Size(174, 23);
            textBoxEmplyoeeId.TabIndex = 35;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 83);
            label2.Name = "label2";
            label2.Size = new Size(90, 15);
            label2.TabIndex = 34;
            label2.Text = "ID zaměstnance";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(148, 21);
            label1.TabIndex = 33;
            label1.Text = "Přidávání zakázky";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 215);
            label3.Name = "label3";
            label3.Size = new Size(49, 15);
            label3.TabIndex = 46;
            label3.Text = "Hodiny:";
            // 
            // textBoxHours
            // 
            textBoxHours.Location = new Point(12, 233);
            textBoxHours.Name = "textBoxHours";
            textBoxHours.Size = new Size(174, 23);
            textBoxHours.TabIndex = 47;
            // 
            // AddContract
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(197, 313);
            Controls.Add(textBoxHours);
            Controls.Add(label3);
            Controls.Add(textBoxCustomerName);
            Controls.Add(label6);
            Controls.Add(dateTimePicker);
            Controls.Add(label5);
            Controls.Add(textBoxWorkId);
            Controls.Add(label4);
            Controls.Add(buttonCancel);
            Controls.Add(buttonAddContract);
            Controls.Add(textBoxEmplyoeeId);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "AddContract";
            Text = "AddContract";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox textBoxCustomerName;
        private Label label6;
        private DateTimePicker dateTimePicker;
        private Label label5;
        private TextBox textBoxWorkId;
        private Label label4;
        private Button buttonCancel;
        private Button buttonAddContract;
        private TextBox textBoxEmplyoeeId;
        private Label label2;
        private Label label1;
        private Label label3;
        private TextBox textBoxHours;
    }
}