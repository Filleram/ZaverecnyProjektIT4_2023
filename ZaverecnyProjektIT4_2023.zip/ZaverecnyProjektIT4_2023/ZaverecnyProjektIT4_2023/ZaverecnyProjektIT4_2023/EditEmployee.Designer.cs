﻿namespace ZaverecnyProjektIT4_2023
{
    partial class EditEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxPhone = new TextBox();
            label7 = new Label();
            textBoxEmail = new TextBox();
            label6 = new Label();
            dateTimePicker = new DateTimePicker();
            label5 = new Label();
            textBoxJob = new TextBox();
            label4 = new Label();
            buttonCancel = new Button();
            buttonEditWork = new Button();
            textBoxLastName = new TextBox();
            label3 = new Label();
            textBoxFirstName = new TextBox();
            label2 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // textBoxPhone
            // 
            textBoxPhone.Location = new Point(120, 208);
            textBoxPhone.Name = "textBoxPhone";
            textBoxPhone.Size = new Size(100, 23);
            textBoxPhone.TabIndex = 47;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(120, 190);
            label7.Name = "label7";
            label7.Size = new Size(27, 15);
            label7.TabIndex = 46;
            label7.Text = "Tel.:";
            // 
            // textBoxEmail
            // 
            textBoxEmail.Location = new Point(12, 208);
            textBoxEmail.Name = "textBoxEmail";
            textBoxEmail.Size = new Size(100, 23);
            textBoxEmail.TabIndex = 45;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(12, 190);
            label6.Name = "label6";
            label6.Size = new Size(39, 15);
            label6.TabIndex = 44;
            label6.Text = "Email:";
            // 
            // dateTimePicker
            // 
            dateTimePicker.Location = new Point(12, 162);
            dateTimePicker.Name = "dateTimePicker";
            dateTimePicker.Size = new Size(200, 23);
            dateTimePicker.TabIndex = 43;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(10, 144);
            label5.Name = "label5";
            label5.Size = new Size(81, 15);
            label5.TabIndex = 42;
            label5.Text = "Datum naroz.:";
            // 
            // textBoxJob
            // 
            textBoxJob.Location = new Point(12, 69);
            textBoxJob.Name = "textBoxJob";
            textBoxJob.Size = new Size(100, 23);
            textBoxJob.TabIndex = 41;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(10, 51);
            label4.Name = "label4";
            label4.Size = new Size(28, 15);
            label4.TabIndex = 40;
            label4.Text = "Job:";
            // 
            // buttonCancel
            // 
            buttonCancel.Location = new Point(28, 249);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(75, 23);
            buttonCancel.TabIndex = 39;
            buttonCancel.Text = "Zrušit";
            buttonCancel.UseVisualStyleBackColor = true;
            buttonCancel.Click += buttonCancel_Click;
            // 
            // buttonEditWork
            // 
            buttonEditWork.Location = new Point(109, 249);
            buttonEditWork.Name = "buttonEditWork";
            buttonEditWork.Size = new Size(75, 23);
            buttonEditWork.TabIndex = 38;
            buttonEditWork.Text = "Upravit";
            buttonEditWork.UseVisualStyleBackColor = true;
            buttonEditWork.Click += buttonEditWork_Click;
            // 
            // textBoxLastName
            // 
            textBoxLastName.Location = new Point(120, 113);
            textBoxLastName.Name = "textBoxLastName";
            textBoxLastName.Size = new Size(100, 23);
            textBoxLastName.TabIndex = 37;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(120, 95);
            label3.Name = "label3";
            label3.Size = new Size(54, 15);
            label3.TabIndex = 36;
            label3.Text = "Příjmení:";
            // 
            // textBoxFirstName
            // 
            textBoxFirstName.Location = new Point(12, 113);
            textBoxFirstName.Name = "textBoxFirstName";
            textBoxFirstName.Size = new Size(100, 23);
            textBoxFirstName.TabIndex = 35;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(10, 95);
            label2.Name = "label2";
            label2.Size = new Size(83, 15);
            label2.TabIndex = 34;
            label2.Text = "Křestní jméno:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(10, 14);
            label1.Name = "label1";
            label1.Size = new Size(187, 21);
            label1.TabIndex = 33;
            label1.Text = "Editování zaměstnance";
            // 
            // EditEmployee
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(236, 290);
            Controls.Add(textBoxPhone);
            Controls.Add(label7);
            Controls.Add(textBoxEmail);
            Controls.Add(label6);
            Controls.Add(dateTimePicker);
            Controls.Add(label5);
            Controls.Add(textBoxJob);
            Controls.Add(label4);
            Controls.Add(buttonCancel);
            Controls.Add(buttonEditWork);
            Controls.Add(textBoxLastName);
            Controls.Add(label3);
            Controls.Add(textBoxFirstName);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "EditEmployee";
            Text = "EditEmployee";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxPhone;
        private Label label7;
        private TextBox textBoxEmail;
        private Label label6;
        private DateTimePicker dateTimePicker;
        private Label label5;
        private TextBox textBoxJob;
        private Label label4;
        private Button buttonCancel;
        private Button buttonEditWork;
        private TextBox textBoxLastName;
        private Label label3;
        private TextBox textBoxFirstName;
        private Label label2;
        private Label label1;
    }
}